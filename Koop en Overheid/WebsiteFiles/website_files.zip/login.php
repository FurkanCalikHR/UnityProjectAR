<?php

$conn = mysqli_connect('localhost', 'id13967395_admin', 'c0l!}EaYf2-/n<Ay', 'id13967395_main');

if(mysqli_connect_errno())
{
	echo "Verbinding mislukt.";
	exit();
}

$username = $_POST["username"];
$password = $_POST["password"];

$namecheckquery = "SELECT username, password, privacyconditions, score, blacktext FROM users WHERE username='" . $username . "' AND password='" . $password . "';";

$namecheck = mysqli_query($conn, $namecheckquery) or die("Query voor login is mislukt.");

if(mysqli_num_rows($namecheck) != 1)
{
    echo "Verkeerde gebruikersnaam en/of wachtwoord.";
    exit();
} else {
    $information = mysqli_fetch_assoc($namecheck);
    echo "0\t" . $information["score"] . "\t" . $information["privacyconditions"] . "\t" . $information["blacktext"];
}
?>