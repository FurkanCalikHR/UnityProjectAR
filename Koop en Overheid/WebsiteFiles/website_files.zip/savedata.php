<?php

$conn = mysqli_connect('localhost', 'id13967395_admin', 'c0l!}EaYf2-/n<Ay', 'id13967395_main');

if(mysqli_connect_errno())
{
	echo "Verbinding mislukt.";
	exit();
}

$username = $_POST["username"];
$score = $_POST["score"]; 
$privacyconditions = $_POST["privacyconditions"];
$blacktext = $_POST["blacktext"];

$namecheckquery = "SELECT username FROM users WHERE username='" . $username . "';";

$namecheck = mysqli_query($conn, $namecheckquery) or die("Query voor login is mislukt.");

if(mysqli_num_rows($namecheck) != 1)
{
    exit();
} else {
    $updatequery = "UPDATE users SET score = " . $score . ", privacyconditions = " . $privacyconditions . ", blacktext = " . $blacktext . " WHERE username = '" . $username. "';"; 
    mysqli_query($conn, $updatequery) or die("Query voor update settings is mislukt.");
}
?>