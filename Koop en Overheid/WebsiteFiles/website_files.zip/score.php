<?php

$conn = mysqli_connect('localhost', 'id13967395_admin', 'c0l!}EaYf2-/n<Ay', 'id13967395_main');

if(mysqli_connect_errno())
{
	echo "Verbinding mislukt.";
	exit();
}

$fetchhighscore = "SELECT username, score FROM users ORDER BY score DESC LIMIT 10;";
$result = mysqli_query($conn, $fetchhighscore) or die("Query voor highscores is mislukt.");

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
    echo $row["username"]. "\t" . $row["score"]. "\n";
    }
} else {
echo "0 results";
}
?>